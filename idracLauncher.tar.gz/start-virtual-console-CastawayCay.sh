#!/bin/bash

#borrowed from https://gist.github.com/xbb/4fd651c2493ad9284dbcb827dc8886d6

#echo -n 'Host: '
#read drachost
drachost='192.168.1.122'

#echo -n 'Username: '
#read dracuser
dracuser=root

echo -n 'Password: '
read -s dracpwd
echo


./jre/bin/java -cp avctKVM.jar -Djava.library.path=./lib com.avocent.idrac.kvm.Main ip=$drachost kmport=5900 vport=5900 user=$dracuser passwd=$dracpwd apcp=1 version=2 vmprivilege=true "helpurl=https://$drachost:443/help/contents.html"
