Need a specific legacy local jre for this to work:

1. Obtain jdk1.7.0_80 from oracle's archive (server JRE)

	a. find "server-jre-7u80-linux-x64.tar.gz" at https://www.oracle.com/technetwork/java/javase/downloads/java-archive-downloads-javase7-521261.html

2. unzip jdk1.7.0_80 and cut/paste the jre folder in this directory

3. run and enjoy!
